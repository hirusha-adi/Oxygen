# Youtube Playlist (Functional + Responsive)

A Pen created on CodePen.io. Original URL: [https://codepen.io/RIR360/pen/GRWNxpo](https://codepen.io/RIR360/pen/GRWNxpo).

This pen shows you how you can create a YouTube playlist from scratch with pure CSS and JavaSCript.
This is not just responsive it's also functional!

*         Working dropdown toggle button
*         Shows the current and total videos correctly
*         Loads the embedded video on click.